package overloading;

public class Puerta {
    int NoPuerta;
    boolean Estado;
    public Puerta(int P, boolean E)
    {
        this.NoPuerta = P;
        this.Estado = E;
    }
}
