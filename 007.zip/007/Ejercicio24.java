
public class Ejercicio24 {
    
    public static void main(String[] args)
    {
        double z = 0;
        double m = 80;
        double s = 4;
        double X = 85.3;
        System.out.println("Bienvenido al programa que calcula la desviacion estandar normal");
        z = (X-m)/s;
        System.out.println("La desviacion estandar nomral es: " +z);
    }
}